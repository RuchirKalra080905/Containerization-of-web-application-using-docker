# Dockerized Web Application

A simple Node.js web application containerized with Docker.

## Quick Start

### Using Docker Compose (Recommended)
```bash
docker-compose up --build
```

### Using Docker directly
```bash
# Build the image
docker build -t web-app .

# Run the container
docker run -p 3000:3000 web-app
```

## Access the Application
Open your browser and navigate to: http://localhost:3000

## Docker Commands

### Build and run with Docker Compose
```bash
docker-compose up --build -d
```

### Stop the application
```bash
docker-compose down
```

### View logs
```bash
docker-compose logs -f
```

### Rebuild after changes
```bash
docker-compose up --build
```

## Features
- Multi-stage Docker build for optimization
- Non-root user for security
- Health checks
- Static file serving
- API endpoint for health monitoring