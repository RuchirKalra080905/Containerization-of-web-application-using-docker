async function checkHealth() {
    const statusDiv = document.getElementById('status');
    
    try {
        const response = await fetch('/api/health');
        const data = await response.json();
        
        statusDiv.innerHTML = `
            <strong>Status:</strong> ${data.status}<br>
            <strong>Timestamp:</strong> ${data.timestamp}
        `;
        statusDiv.style.background = '#d4edda';
        statusDiv.style.color = '#155724';
    } catch (error) {
        statusDiv.innerHTML = `<strong>Error:</strong> ${error.message}`;
        statusDiv.style.background = '#f8d7da';
        statusDiv.style.color = '#721c24';
    }
}